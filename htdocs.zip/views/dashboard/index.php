<?php include_once (self::block('header')) ?>
<section class="main">
	<?php include_once (self::block('topbar')) ?>
	<section class="bodyContent">
    </section>
</section>
<?php include_once (self::block('footer')) ?>