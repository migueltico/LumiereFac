<script src="public/assets/js/jquery.js"></script>
<script src="public/assets/js/sweet.js"></script>
<!-- <script src="public/assets/js/charts.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<!-- <script src="https://unpkg.com/@popperjs/core@2"></script> -->
<script src="public/assets/js/bootstrap.js"></script>
<script src="public/assets/js/main.js"></script>
<script src="public/assets/js/clientes.js"></script>
<script src="public/assets/js/usuarios.js"></script>
<script src="public/assets/js/facturacion.js"></script>
<script src="public/assets/js/inventario.js"></script>
<script src="public/assets/js/admin.js"></script>
<script src="public/assets/js/dashboard.js"></script>
<script src="public/assets/js/sucursal.js"></script>
<script src="public/assets/js/menu.js"></script>
</body>

</html>