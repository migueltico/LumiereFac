<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="utf-8">
	<!-- <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- <link rel="stylesheet" href="public/assets/css/bootstrap.css"> -->
	<!-- <link rel="stylesheet" href="public/assets/css/bootstrap-grid.css"> -->
	<link rel="stylesheet" href="public/assets/css/main.min.css">
	<!-- <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500&display=swap" rel="stylesheet"> -->
	<link rel="icon" type="image/png" href="public/assets/img/favicon.ico" />
	<title>dashboard</title>
</head>