<div class="col-lg-10 col-md-12 col-sm-12">
    <div class="card mb-5  shadow">
        <canvas id="myChart" style="display: block; width: 500px; height: 200px;"></canvas>
    </div>
    <script>
  
    </script>
</div>