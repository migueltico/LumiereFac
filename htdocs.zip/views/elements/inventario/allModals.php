<section id="modalsContainer">
    <?php include_once(self::modal('modalAddProduct')) ?>
    <?php include_once(self::modal('modalEditProduct')) ?>
    <?php include_once(self::modal('modalShowGallery')) ?>
</section>