<?php namespace config;

// la calse debe llamarse igual que el controlador respetando mayusculas
class view
{
    public function nueva_funcion($var = null)
    {
        // Codigo
    }
}