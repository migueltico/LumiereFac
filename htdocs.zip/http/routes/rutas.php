<?php

namespace http\routes;

use config\route;

//------------- +++ RUTAS GET +++ -----------------//

//+++++++++++ LOGIN +++++++++++//
route::post('/validateauth', 'loginController@validar');
route::post('/validateauth*', 'loginController@validar');
route::get('/logout', 'loginController@logout');
route::get('/', 'loginController@index', ['loginMiddleware@auth']);
//+++++++++++ DASHBOARD +++++++++++//
route::get('/dashboard', 'dashboardController@index', ['loginMiddleware@auth']);
//+++++++++++ SUCURSAL +++++++++++//
route::post('/sucursal', 'sucursalController@index', ['loginMiddleware@auth']);
route::post('/sucursal/addSucursal', 'sucursalController@addSucursal');
route::post('/sucursal/updateSucursal', 'sucursalController@updateSucursal');
route::post('/sucursal/getSucursalById', 'sucursalController@getSucursalById');
route::post('/sucursal/refresh/sucursaltable', 'sucursalController@sucursaltable');
route::post('/sucursal/deleteSucursal', 'sucursalController@deleteSucursal');
//+++++++++++ ADMIN +++++++++++//
route::group('admin', function () {
    route::post('/gastos', 'adminController@indexGastos', ['loginMiddleware@auth']);
    route::post('/gastos/saveGastos', 'adminController@saveGastos');
    route::post('/categoriaprecios', 'adminController@indexCategoriaPrecios', ['loginMiddleware@auth']);
    route::post('/categoriastallas', 'adminController@indexCategoriasTallas', ['loginMiddleware@auth']);
    route::post('/categoriastallas/AddCategoria', 'adminController@AddCategoria');
    route::post('/categoriastallas/AddTalla', 'adminController@AddTalla');
    route::post('/categoriastallas/table', 'adminController@tableCategoriaTallas');
    route::post('/categoriastallas/editCategoria', 'adminController@editCategorias');
    route::post('/categoriastallas/editTallas', 'adminController@editTallas');
    route::post('/categoriaprecios/table', 'adminController@tableCategoriaPrecios');
    route::post('/categoriaprecios/add', 'adminController@AddCategoriaPrecios');
    route::post('/categoriaprecios/edit', 'adminController@EditCategoriaPrecios');
    route::post('/categoriaprecios/delete', 'adminController@DeleteCategoriaPrecios');
});
//+++++++++++ INVENTARIO +++++++++++//
route::group('inventario', function () {
    route::post('/listarproductos', 'inventarioController@index', ['loginMiddleware@auth']);
    route::post('/addproduct', 'inventarioController@addproduct');
    route::post('/updateProduct', 'inventarioController@updateProduct');
    route::post('/getProductById', 'inventarioController@getProductById');
    route::post('/refresh/producttable', 'inventarioController@producttable');
    route::post('/refresh/RefreshBySucursalTableProduct', 'inventarioController@RefreshBySucursalTableProduct');
    route::post('/generar/codigobarras', 'inventarioController@generarCodigo');
    route::post('/search', 'inventarioController@searchProduct');
    route::post('/search/stock', 'inventarioController@searchProductstock');
    route::post('/addstock', 'inventarioController@addstock');
    route::post('/refreshProductstock', 'inventarioController@refreshProductstock');
    route::post('/saveProductPrice', 'inventarioController@saveProductPrice');
    route::post('/updateStock', 'inventarioController@updateStock');
    route::post('/updateMinStock', 'inventarioController@updateMinStock');
    route::post('/calcular/sugerido', 'inventarioController@calcular_sugerido');
});
//+++++++++++ FACTURACION +++++++++++//
route::group('facturacion', function () {
    route::post('/facturar', 'facturacionController@index', ['loginMiddleware@auth']);
    route::post('/search/product', 'facturacionController@searchProduct');
    route::post('/search/product/ctrlq', 'facturacionController@searchProductCtrlQ');
    route::post('/facturaVenta', 'inventarioController@getFact');
});
//+++++++++++ CLIENTES +++++++++++//
route::group('clientes', function () {
    route::post('/lista', 'clientesController@index', ['loginMiddleware@auth']);
    route::post('/addcliente', 'clientesController@addNewClient');
    route::post('/getClienteById', 'clientesController@getClienteById');
    route::post('/updateClienteById', 'clientesController@updateClienteById');
    route::post('/refreshClients', 'clientesController@refreshClients');
    route::post('/search/searchclient', 'clientesController@searchClient');
});
//+++++++++++ SUBIDA DE ARCHIVOS +++++++++++//
route::post('/upload/files', 'uploadsController@uploads');
route::post('/remove/img', 'uploadsController@removeImgAdd');
//+++++++++++ FACTURACION +++++++++++//
//route::get('/', 'indexController@dashboard', ["loginMiddleware@validate_login"]);


// route::group('admin', function () {


//     route::get('/', 'indexController@index');
//     route::get('/contact1', 'indexController@index');
//     route::get('/blog/buscar', 'indexController@index');
//     route::get('/tienda/producto1/:id', 'indexController@index');
//     route::middleware(['loginMiddleware@token', 'login@prueba'], function () {
//         route::post('/blog/buscar/id', 'indexController@index', ["login@prueba"]);
//         route::get('/home2', 'indexController@index');
//         route::get('/contact2', 'indexController@index');
//         route::get('/blog/buscar2', 'indexController@index');
//         route::get('/tienda/producto2/:id', 'indexController@index', ['login@prueba', 'login@token']);
//     });
// });
// route::middleware(['loginMiddleware@validate_login', 'loginMiddleware@token'], function () {
//     route::get('/', 'indexController@index', ['loginMiddleware@prueba', 'loginMiddleware@prueba']);
//     route::get('/contact', 'indexController@index');
//     route::get('/blog/buscar', 'indexController@index');
//     route::get('/tienda/producto3/:id', 'indexController@index');
//     route::get('/home/:id', 'indexController@b', ['loginMiddleware@prueba']);
//     route::get('/home', 'indexController@b', ['loginMiddleware@prueba']);
//     route::post('/home/:id', 'indexController@b', ['loginMiddleware@prueba']);
// });
// route::get('/tienda/producto/:idproduct/categoria/:cat_id/user/:userid', 'indexController@index');
// route::get('/tienda/producto5/:idproduct/categoria/:cat_id/user/:userid', 'indexController@index');
// route::get('/tienda/producto/:idproduct/categoria/:cat_id/user/prueba', 'indexController@index');
// route::get('/contact/custom', 'indexController@index');
// route::get('/blog/buscar/id', 'indexController@index');
// route::get('/tienda/producto4/:idproduct/categoria/:cat_id', 'indexController@index', ["loginMiddleware@prueba"]);
// route::post('/tienda/producto', 'indexController@index', ["loginMiddleware@prueba"]);

// route::post('/tienda/producto', 'indexController@index', ["loginMiddleware@prueba"]);
